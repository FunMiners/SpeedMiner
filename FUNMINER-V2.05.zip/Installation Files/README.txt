FUNMINER - v2.01 build 0144
MD5: 4ca545ec793c0bd17ea4cb6c6e3cc10d
SHA-1: c31839cd956540c7b27a94755769a878ca69d065

 Connecting to the Linux Serial Console from Windows           Serial Settings
 ---------------------------------------------------------     ---------------
 Find the COM# from Device Manager > Ports (COM & LPT)         115200/8N1
 Look for USB Serial Device (COM#). Example: COM3              
 Or run the following powershell command to list ports:        Baud: 115200
 [System.IO.Ports.SerialPort]::getportnames()                  Data Bits: 8
                                                               Parity Bit: No
 Open Putty (putty.org) and select Serial. Enter COM# for      Stop Bit: 1
 serial line and 115200 for Speed. Clock Open.
 
 
 
 Connecting to the Linux Serial Console from Linux/Mac
 -----------------------------------------------------------------------------
 Find the device from the terminal with: "ls /dev/tty*" or "dmesg | grep tty"
 On Linux the Bash Bunny may be /dev/ttyUSB0 or /dev/ttyACM0
 Connect to the serial device with screen. (apt-get install screen if needed)
 Example: "sudo screen /dev/ttyACM0 115200"
 Disconnect with keyboard combo: CTRL+a followed by CTRL+\

Version: GnuPG v1

-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA1

iQEcBAEBAgAGBQJYWyXaAAoJEPPlPMKyJOnlSvUIAJ9hykis7dXml/qU00fPb1yN
f/6rw1ywZLNdkOYueLQaFhNZddBRgKZa+Oru3NP5uoQ+KQmGuoVzpimVSzsor0l8
LO/35dB3Zd9VyHfEKznbAopYsXec21IRrGXtMUSM9fjcZMWQMgZHUujzsoFrqNy7
xdZImWzwU0/mG+hFDQVSJksi0F5i9P6YdaZaPZhyd8HJMMMjT872pc0eYrRZbC/X
Yimx+Z+waf+cIUHmag0kR0AG/+AK9RbxllGXpCfz1EQpKO8wGo01mo4GzcNB0/dL
bnQq+m2Gi8ngfOz0jzdfkJHIRbkOzLIP0TInEPOJ/ZzsLyM8K3lNPOuMXUV3+Fk=
=LYWE
-----END PGP SIGNATURE-----